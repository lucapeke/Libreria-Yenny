import os
from app import login

os.environ['TCL_LIBRARY'] = r'C:\Users\eros0\AppData\Local\Programs\Python\Python312\tcl\tcl8.6'
os.environ['TK_LIBRARY'] = r'C:\Users\eros0\AppData\Local\Programs\Python\Python312\tcl\tk8.6'

if __name__ == "__main__":
    
    login.ventana_inicio()
